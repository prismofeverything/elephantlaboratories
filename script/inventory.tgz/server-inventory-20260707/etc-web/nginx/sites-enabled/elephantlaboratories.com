upstream elephantlaboratories {
    server 127.0.0.1:21112;
}

server {
    server_name www.elephantlaboratories.com;
    return 301 https://elephantlaboratories.com$request_uri;
}

server {
    listen 443 ssl;
    #listen 80;
    server_name elephantlaboratories.com;
    ssl_protocols TLSv1 TLSv1.1 TLSv1.2; # Dropping SSLv3, ref: POODLE
    ssl_prefer_server_ciphers on;
    ssl_certificate /etc/letsencrypt/live/elephantlaboratories.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/elephantlaboratories.com/privkey.pem;
    root /home/ryan/elephantlaboratories/resources/communal;

    index index.html;

    # location ~ \.(js|css|png|jpg|jpeg|gif|ico|html|woff|woff2|ttf|svg|eot|otf)$ {
    location /assets/fonts/ {
        add_header "Access-Control-Allow-Origin" "https://cloud.typography.com";
        add_header "Access-Control-Allow-Credentials" true;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS';
        add_header 'Access-Control-Allow-Headers' 'DNT,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Content-Range,Range';
        add_header 'Access-Control-Expose-Headers' 'DNT,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Content-Range,Range';
        #expires 1M;
        #access_log off;
        #add_header Cache-Control "public";

        #if (-f $request_filename) {
        #    break;
        #}
    }

    # location ~* \.(ttf|ttc|otf|eot|woff|font.css)$ {
        # add_header "Access-Control-Allow-Origin" "*";
        # expires 1M;
        # access_log off;
        # add_header "Cache-Control" "public";
        # add_header Content-Security-Policy "default-src 'self';font-src 'self' https://cloud.typography.com; object-src 'none';frame-src 'none';upgrade-insecure-requests;";
        # add_header Strict-Transport-Security "max-age=63072000; includeSubdomains; ";
        # add_header X-Frame-Options "DENY";
        # add_header X-XSS-Protection "1; mode=block";
    # }

    location / {
        # add_header 'Access-Control-Allow-Origin' '*';
        # add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS';
        # add_header 'Access-Control-Allow-Headers' 'DNT,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Content-Range,Range';
        # add_header 'Access-Control-Expose-Headers' 'DNT,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Content-Range,Range';
        proxy_set_header  X-Real-IP  $remote_addr;
        proxy_set_header  X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header Host $http_host;
        proxy_redirect off;

        if ($request_method != GET) {
            proxy_pass http://elephantlaboratories;
            break;
        }

        # serve requested file if present
        if (-f $request_filename) {
            break;
        }

        # serve cached .html if present
        if (-f $request_filename.html) {
            rewrite (.*) $1.html break;
        }

        # pass anything left to the application
        if (!-f $request_filename) {
            proxy_pass http://elephantlaboratories;
            break;
        }
    }

    error_page   500 502 503 504  /50x.html;
    location = /50x.html {
        root   html;
    }
}
