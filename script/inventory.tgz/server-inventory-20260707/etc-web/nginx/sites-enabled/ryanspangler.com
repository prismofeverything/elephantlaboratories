server {
        listen 443 ssl;
        server_name ryanspangler.com *.ryanspangler.com;

        ssl_protocols TLSv1 TLSv1.1 TLSv1.2; # Dropping SSLv3, ref: POODLE
        ssl_prefer_server_ciphers on;
        ssl_certificate /etc/letsencrypt/live/ryanspangler.com/fullchain.pem;
        ssl_certificate_key /etc/letsencrypt/live/ryanspangler.com/privkey.pem;

        root /home/ryan/ryanspangler/resources/public;
        index index.html;

	location / {
	        proxy_set_header  X-Real-IP  $remote_addr;
	        proxy_set_header  X-Forwarded-For $proxy_add_x_forwarded_for;
	        proxy_set_header Host $http_host;
	        proxy_redirect off;

	        if (-f $request_filename) {
	           break;
	        }

	        if (-f $request_filename/index.html) {
	            rewrite (.*) $1/index.html break;
	        }

	        if (-f $request_filename.html) {
	            rewrite (.*) $1.html break;
	        }

	        if (!-f $request_filename) {
#	            proxy_pass http://metamagicreality;
	            break;
	        }
	}

	location /music {
		autoindex on;
	}
}
